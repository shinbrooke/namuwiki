from bs4 import BeautifulSoup as bs
import time
import re
from undetected_chromedriver import Chrome
import string

# 한 페이지의 soup 객체 구하기
def get_soup(url, driver):
    # 드라이버 실행해서 html 소스 얻기 
    driver.get(url) # 페이지 url에 접근
    time.sleep(3) # 기다리기
    html = driver.page_source # 전체 html 소스 얻기    

    # html 소스에서 가장 최신 revision 번호 찾기
    soup = bs(html, 'html.parser')

    return soup

# 한 페이지의 revision 구하기
def get_revisions_part(soup):
    # revisions_part = soup.find('form', action=True)
    revisions_part = soup.find_all('span')
    revisions_part = [revision for revision in revisions_part if 'data-v-6cbb5b59="" data-v-c68d158c=""' in str(revision)]
    revisions_part = [revision.get_text().strip() for i, revision in enumerate(revisions_part) if i%2==1]
    return revisions_part

# 한 페이지의 수정 시간 구하기
def get_revision_times_part(soup):
    revision_times_part = soup.find_all('time')
    revision_times_part = [t.attrs['datetime'].strip() for t in revision_times_part]
    revision_times_part = revision_times_part[:-5] # '최근 변경'의 시간 제거
    return revision_times_part

# 한 페이지의 유저네임 구하기
def get_users(soup):
    users_part = soup.find_all('div', class_='trigger')
    # users_part = users_part.find_all('a')
    users_part = [user.get_text().strip() for user in users_part]
    return users_part

# 한 페이지의 코멘트 구하기
def get_comments(soup):
    comments_part = soup.find_all('span', class_='dDmyA0X6')
    comments_part = [comment.get_text().strip() for comment in comments_part]
    return comments_part

# 한 페이지의 필요한 정보를 합치는 함수
def get_combined(revisions, times, users, comments):
    return zip(revisions, times, users, comments)

# 나무위키 한 항목의 revision 목록 구하기
def get_revision_list(url, driver):
    revision_list = []

    soup = get_soup(url, driver)

    # 최신 revision 번호 구하기
    latest_id = soup.find('strong', string=re.compile(r'r[0-9]+?'))
    latest_id = latest_id.get_text().strip()
    latest_id = int(latest_id.strip('r'))

    # revision id를 고려하며 페이지 탐색
    i = latest_id
    combined = get_combined(get_revisions_part(soup), get_revision_times_part(soup), get_users(soup), get_comments(soup))
    revision_list.append(combined)

    while True:
        # url 변형
        i = i - 30 # 30 == 나무위키 항목 역사 페이지의 최대 표시 리비전 개수
        if i <= 0:
            break
        url_next = url + f'?from={i}' # 30 == 나무위키 항목 역사 페이지의 최대 표시 리비전 개수

        # html 소스에서 한 페이지의 revision 리스트 구해서 저장
        soup = get_soup(url_next, driver)
        combined = get_combined(get_revisions_part(soup), get_revision_times_part(soup), get_users(soup), get_comments(soup))
        revision_list.append(combined)

    # flatten
    revision_list = [y for x in revision_list for y in x]
    
    return revision_list

# url_list의 내용을 뽑는 함수
def get_contents(driver, field):

    # url에 넣을 키워드 구하기
    with open(f'keywords_{field}.txt', 'r', encoding='utf-8') as f:
        keywords = f.readlines()
        keywords = [keyword.strip() for keyword in keywords]
        keywords = [keyword for keyword in keywords if keyword]

    # url_list = [url_template + keyword for keyword in keywords]
    ## url list를 만들기보다는 keyword별로 루프하며 url을 즉석에서 만드는 방식 이용

    res = {}
    for keyword in keywords:
        url = url_template + keyword
        res[keyword] = get_revision_list(url, driver)

        # txt 파일로 출력(한 항목마다)
        with open(f'data_{field}.txt', 'a', encoding='utf-8') as f:
            f.write(str(list(res.items())[-1]))

    return res

def get_all(fields):
    driver = Chrome()        

    field_dict = {}
    for field in fields:
        # 출력(한꺼번에)
        field_dict[field] = get_contents(driver, field)
        # with open('data.txt', 'a', encoding='utf-8') as f:
        #     f.write(res)
    
    driver.quit() # 드라이버 종료
    return field_dict


# url 설정
url_template = 'https://namu.wiki/history/'

fields = ['sayngmwulhak', 'swuhakyonge', 'mwullihak', 'idol', 'media', 'sportsyonge']

field_dict = get_all(fields)
