import pandas as pd
import numpy as np
from datetime import datetime
import random

import data_sayngmwulhak
import data_swuhakyonge
import data_mwullihak

import data_sportsyonge
import data_idol
import data_media

sayngmwulhak = data_sayngmwulhak.my_tuple
swuhakyonge = data_swuhakyonge.my_tuple
mwullihak = data_mwullihak.my_tuple

sportsyonge = data_sportsyonge.my_tuple
idol = data_idol.my_tuple
media = data_media.my_tuple

def get_df(my_tuple):
  df_base = get_df_base(my_tuple)
  df = pd.DataFrame(df_base, columns=['page', 'code', 'change', 'time', 'uname', 'other'])
  df = df[['time', 'code', 'change', 'uname', 'other', 'page']]
  df['time'] = df['time'].apply(get_datetime)
  df.code = 'r' + df.code.astype(str)

  return df

def get_datetime(datetime_str):
  datetime_obj = datetime.strptime(datetime_str, '%Y-%m-%dT%H:%M:%S.000Z')
  return datetime_obj

def get_revision_lists(my_tuple):
  temp = [item[-1] for item in my_tuple]
  revision_lists = []
  for revision_list in temp:
    revision_lists.append([list(revision) for revision in revision_list])
  return revision_lists

def get_page_lists(my_tuple):
  page_lists = [[[item[0]]]*len(item[-1]) for item in my_tuple]
  return page_lists

def aug_order(revision_lists):
  res = []
  for revision_list in revision_lists:
    temp = reversed(list(enumerate(reversed(revision_list))))
    temp_mod = []
    for each in temp:
      res_part = [each[0]+1] + each[1]
      temp_mod.append(res_part)

    res.append(temp_mod)

  return res

def get_df_base(my_tuple):
  page_lists = get_page_lists(my_tuple)
  revision_lists = get_revision_lists(my_tuple)
  revision_lists = aug_order(revision_lists)
  df_base = []
  for item in zip(page_lists, revision_lists):
    page_list = item[0]
    revision_list = item[1]
    for page, revision in zip(page_list, revision_list):
        df_base.append(page + revision)
      
  return df_base

def get_concatted(concat_list):
  concatted = pd.concat(concat_list)
  concatted.index = range(len(concatted))
  return concatted

# dataacademic.csv
sayngmwulhak_df = get_df(sayngmwulhak)
sayngmwulhak_df['category'] = ['생물학']*len(sayngmwulhak_df)
swuhakyonge_df = get_df(swuhakyonge)
swuhakyonge_df['category'] = ['수학용어']*len(swuhakyonge_df)
mwullihak_df = get_df(mwullihak)
mwullihak_df['category'] = ['수학용어']*len(mwullihak_df)

concatted_academic = get_concatted([sayngmwulhak_df, swuhakyonge_df, mwullihak_df])

## Trim
pages_keep = list(concatted_academic.page.unique())
random.shuffle(pages_keep) # 주의: 시드값 고정을 해놓지 않았기에 메인 디렉토리에 있는 파일과 다른 파일이 나올 수 있음

pages_keep = pages_keep[:500]

df_academic = concatted_academic[concatted_academic['page'].isin(pages_keep)]
df_academic.index = range(len(df_academic))
df_academic.to_csv('dataacademic_aug.csv', index=False)

# dataculture.csv
sports_df = get_df(sportsyonge)
sports_df['category'] = ['스포츠용어']*len(sports_df)
idol_df = get_df(idol)
idol_df['category'] = ['아이돌']*len(idol_df)
media_df = get_df(media)
media_df['category'] = ['영화&드라마']*len(media_df)

concatted_culture = get_concatted([sports_df, idol_df, media_df])
concatted_culture.to_csv('dataculture_aug.csv')
